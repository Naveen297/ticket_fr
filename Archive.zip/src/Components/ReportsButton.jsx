import React from 'react';
import { FiBarChart2, FiFileText } from 'react-icons/fi'; // Importing icons

const ReportsButton = () => {
    return (
        <button className="flex items-center px-4 py-2 text-white transition duration-300 bg-red-400 rounded-md hover:bg-red-500">
        <FiFileText className="mr-2" size={20} />
        <span>Generate Report</span>
    </button>
    );
};

export default ReportsButton;