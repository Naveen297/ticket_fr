import React from "react"
import { UserCircle } from "lucide-react"
import mdewhite from "../assets/MDE_White.png"
import mdeBeam from "../assets/MahindraBeam.png"
const Header = () => {
  return (
    <>
      {/* The Header */}
      <header className="w-full px-4 py-3 bg-black shadow-md">
        {/* Main header content */}
        <div className="flex items-center justify-between mx-auto max-w-9xl">
          {/* Logo Container */}
          <div className="w-32 h-10">
            <img
              src={mdewhite}
              alt="Logo"
              className="object-contain w-full h-full"
            />
          </div>

          {/* User Icon */}
          <div className="flex items-center">
            <UserCircle className="w-8 h-8 text-white cursor-pointer hover:text-gray-300" />
          </div>
        </div>
      </header>

      {/* Mahindra Beam just below the header */}
      <div className="flex">
        <img
          src={mdeBeam}
          alt="Mahindra Beam"
          className="object-contain w-1/2"
        />
      </div>
    </>
  )
}

export default Header
