import React from 'react';

const Heading = ({HeadingText}) => {
    return (
        <div className="p-4 text-center text-black">
            <h1 className="text-3xl font-ralewaybold">{HeadingText}</h1>
        </div>
    );
};

export default Heading;
