import React from 'react';
import { FiBarChart2, FiFileText } from 'react-icons/fi'; // Importing icons

const ChartButton = ({ onClick }) => {
    return (
        <button
            onClick={onClick}
            className="flex items-center px-4 py-2 text-white transition duration-300 bg-red-400 rounded-md hover:bg-red-500"
        >
           <FiBarChart2 className="mr-2" size={20} /> <span>View Chart</span>
        </button>
    );
};

export default ChartButton;