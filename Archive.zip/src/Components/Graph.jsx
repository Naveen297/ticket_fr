import React, { useState, useEffect } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import { Pie, Bar } from 'react-chartjs-2';
import axios from 'axios';

// Chart.js registration
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
} from 'chart.js';

ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title
);

const BASE_URL = 'http://10.5.6.209:5000'; // Replace with your base URL

const GraphModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [detectionData, setDetectionData] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [chartType, setChartType] = useState('pie');

  // States for Date Range
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Optional: Fetch data on mount (e.g. defaulting to last 7 days)
  useEffect(() => {
    const today = new Date();
    // 7 days including today
    const sevenDaysAgo = new Date(Date.now() - 6 * 24 * 60 * 60 * 1000);

    // Helper function to format date to YYYY-MM-DD
    const formatToDate = (date) => date.toISOString().split('T')[0];

    setStartDate(formatToDate(sevenDaysAgo));
    setEndDate(formatToDate(today));

    // Fetch initial data for last 7 days
    fetchDetectionData(formatToDate(sevenDaysAgo), formatToDate(today));
    // eslint-disable-next-line
  }, []);

  const fetchDetectionData = async (start, end) => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get(
        `${BASE_URL}/get_detection_counters?start_date=${start}&end_date=${end}`
      );
      // The response shape is something like:
      // {
      //   "detection_counters": [
      //     {
      //       "camera_name": "string",
      //       "non_helmet_count": number,
      //       "last_updated": "string"
      //     },
      //     ...
      //   ]
      // }

      const { detection_counters } = response.data;

      // Transform into an object: { camera_name: { non_helmet: count } }
      const transformedData =
        detection_counters?.reduce((acc, item) => {
          acc[item.camera_name] = { non_helmet: item.non_helmet_count };
          return acc;
        }, {}) || {};

      setDetectionData(transformedData);
    } catch (err) {
      console.error('Error fetching detection data:', err);
      setError('Failed to fetch detection data. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = () => {
    if (!startDate || !endDate) {
      setError('Please select both Start Date and End Date.');
      return;
    }
    fetchDetectionData(startDate, endDate);
  };

  // Prepare data for charts
  const labels = Object.keys(detectionData);
  const values = labels.map((key) => detectionData[key].non_helmet);

  // Colors to cycle through
  const chartColors = [
    '#1D4ED8',
    '#10B981',
    '#F59E0B',
    '#EF4444',
    '#8B5CF6',
    '#EC4899',
    '#A855F7',
  ];

  const pieData = {
    labels,
    datasets: [
      {
        label: '# of Non-Helmet Detections',
        data: values,
        backgroundColor: chartColors,
        borderWidth: 1,
        borderColor: '#ffffff',
      },
    ],
  };

  const barData = {
    labels,
    datasets: [
      {
        label: '# of Non-Helmet Detections',
        data: values,
        backgroundColor: chartColors,
        borderRadius: 4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          font: {
            family: 'Inter, sans-serif',
          },
        },
      },
      tooltip: {
        bodyFont: {
          family: 'Inter, sans-serif',
        },
        titleFont: {
          family: 'Inter, sans-serif',
        },
      },
    },
    scales: {
      x: {
        title: {
          display: chartType === 'bar',
          text: 'Camera Name',
          font: {
            family: 'Inter, sans-serif',
          },
        },
        ticks: {
          font: {
            family: 'Inter, sans-serif',
          },
        },
      },
      y: {
        title: {
          display: chartType === 'bar',
          text: 'Number of Non-Helmet Detections',
          font: {
            family: 'Inter, sans-serif',
          },
        },
        ticks: {
          beginAtZero: true,
          font: {
            family: 'Inter, sans-serif',
          },
        },
      },
    },
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40"
      onClick={onClose}
    >
      <div
        className="relative p-6 bg-white rounded-lg shadow-2xl max-w-4xl w-full font-georama max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          className="absolute text-gray-500 top-4 right-4 hover:text-red-500"
          onClick={onClose}
        >
          <AiOutlineClose size={24} />
        </button>

        {/* Header */}
        <div className="mb-6 text-center">
          <h2 className="mb-1 text-3xl font-semibold text-gray-800">
            Helmet Detection Analytics
          </h2>
          <p className="text-sm text-gray-500">
            Explore camera-wise non-helmet detection data by date range.
          </p>
        </div>

        {/* Date Range & Chart Options */}
        <div className="flex flex-col mb-6 md:flex-row md:items-center md:space-x-6">
          {/* Date Range Inputs */}
          <div className="mb-4 md:mb-0">
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setError(null);
              }}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="mb-4 md:mb-0">
            <label className="block mb-1 text-sm font-medium text-gray-700">
              End Date
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setError(null);
              }}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Filter Button */}
          <div className="mt-5">
            <button
              onClick={handleSubmit}
              className="w-full px-4 py-1 text-sm font-semibold text-white transition-colors bg-blue-600 rounded hover:bg-blue-700 md:w-auto"
            >
              Filter
            </button>
          </div>

          {/* Chart Type Selector */}
          <div className="mb-4 md:mb-0">
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Chart Type
            </label>
            <select
              value={chartType}
              onChange={(e) => setChartType(e.target.value)}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="pie">Pie Chart</option>
              <option value="bar">Bar Chart</option>
            </select>
          </div>
        </div>

        {/* Chart Container */}
        <div className="p-6 bg-white border border-gray-200 rounded-lg">
          <h3 className="mb-4 text-xl font-semibold text-center text-gray-700">
            Non-Helmet Detection Distribution
          </h3>
          <div className="flex items-center justify-center w-full h-80">
            {loading && (
              <span className="text-sm text-gray-500">Loading...</span>
            )}

            {!loading && labels.length === 0 && !error && (
              <span className="text-sm text-gray-500">No Data Available</span>
            )}

            {!loading && labels.length > 0 && chartType === 'pie' && (
              <Pie data={pieData} options={chartOptions} />
            )}

            {!loading && labels.length > 0 && chartType === 'bar' && (
              <Bar data={barData} options={chartOptions} />
            )}
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mt-4 text-sm text-center text-red-600">{error}</div>
        )}

        {/* ====================== NEW TABLE SECTION ====================== */}
        {/* Display the table of data for the current date range, if any */}
        {labels.length > 0 && !loading && !error && (
          <div className="p-6 mt-6 bg-white border border-gray-200 rounded-lg">
            <h4 className="mb-3 text-lg font-semibold text-center text-gray-700">
              Detection Data from {startDate} to {endDate}
            </h4>

            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border border-gray-300 rounded-md">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="px-4 py-2 text-sm font-medium text-left text-gray-700 border-b">
                      #
                    </th>
                    <th className="px-4 py-2 text-sm font-medium text-left text-gray-700 border-b">
                      Camera Name
                    </th>
                    <th className="px-4 py-2 text-sm font-medium text-left text-gray-700 border-b">
                      Non-Helmet Count
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {labels.map((cameraName, index) => (
                    <tr
                      key={cameraName}
                      className={`border-b ${
                        index % 2 === 0 ? 'bg-gray-50' : 'bg-white'
                      }`}
                    >
                      <td className="px-4 py-2 text-sm font-medium text-gray-700">
                        {index + 1}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-600">
                        {cameraName}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-600">
                        {detectionData[cameraName].non_helmet}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        {/* ====================== END TABLE SECTION ====================== */}
      </div>
    </div>
  );
};

export default GraphModal;
