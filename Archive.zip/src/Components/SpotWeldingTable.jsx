import React, { useEffect, useState } from 'react';
const formatDateTime = (isoString) => {
  const dateObj = new Date(isoString);

  if (isNaN(dateObj)) {
    return isoString;
  }

  const day = String(dateObj.getDate()).padStart(2, '0');
  const month = String(dateObj.getMonth() + 1).padStart(2, '0');
  const year = dateObj.getFullYear();

  const hours = String(dateObj.getHours()).padStart(2, '0');
  const minutes = String(dateObj.getMinutes()).padStart(2, '0');
  const seconds = String(dateObj.getSeconds()).padStart(2, '0');

  // Construct the desired format: dd/mm/yyyy hh:mm:ss
  return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
};

const SpotWeldingTable = () => {
  const [parsedData, setParsedData] = useState(null);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10; // number of rows per page

  // Fetch & Parse the data
  const fetchData = async () => {
    try {
      const response = await fetch('http://127.0.0.1:8000/final_api_result');
      const data = await response.json();

      // Check if the response is an array and has at least one element
      if (Array.isArray(data) && data.length > 0) {
        // The first element is a JSON string, so parse it
        const parsed = JSON.parse(data[0]);
        setParsedData(parsed);
      } else {
        console.error('API returned empty or invalid array.');
        setParsedData(null);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setParsedData(null);
    }
  };

  useEffect(() => {
    // Fetch data immediately when component mounts
    fetchData();

    // Re-fetch data every 5 seconds (optional)
    const intervalId = setInterval(fetchData, 5000);

    // Cleanup on unmount
    return () => clearInterval(intervalId);
  }, []);

  // ------------------- PAGINATION LOGIC -------------------
  // 1) Get all the columns (keys) from the parsed JSON
  const columns = parsedData ? Object.keys(parsedData) : [];

  // 2) Determine the number of rows we can form.
  //    We assume each key in parsedData has the same array length.
  const totalRows = parsedData && columns.length > 0
    ? parsedData[columns[0]].length
    : 0;

  // 3) Calculate total pages
  const totalPages = Math.ceil(totalRows / pageSize);

  // 4) Handle page changes
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  // 5) Calculate start and end indices for current page
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;

  return (
    <div className="w-full min-h-screen p-6 bg-gray-100">
      <h2 className="mb-4 text-2xl font-bold font-ralewaybold">
        Spot Welding Data
      </h2>
      <div className="mb-8 overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-300 rounded-md shadow-lg">
          {/* Table Header */}
          <thead className="sticky top-0 text-white bg-[#E21837] font-raleway">
            <tr>
              {columns.map((col) => (
                <th key={col} className="px-4 py-2 border">
                  {col}
                </th>
              ))}
            </tr>
          </thead>

          {/* Table Body */}
          <tbody>
            {parsedData
              ? // Map through the rows (by index)
                Array.from({ length: totalRows }, (_, rowIndex) => {
                  // If the rowIndex is not in the current page range, skip rendering
                  if (rowIndex < startIndex || rowIndex >= endIndex) {
                    return null;
                  }

                  return (
                    <tr
                      key={rowIndex}
                      className={`border font-kanitRegular ${
                        rowIndex % 2 === 0 ? 'bg-gray-50' : 'bg-white'
                      } hover:bg-gray-100`}
                    >
                      {columns.map((col) => {
                        let cellValue = parsedData[col][rowIndex];

                        // If the column is dateTime, format it
                        if (col === 'dateTime') {
                          cellValue = formatDateTime(cellValue);
                        }

                        // If the column is WeldScoreFlag, conditionally style the cell
                        if (col === 'WeldScoreFlag') {
                          return (
                            <td
                              key={`${rowIndex}-${col}`}
                              className={`px-4 py-2 border ${
                                cellValue === 'Good'
                                  ? 'bg-green-300'
                                  : cellValue === 'Bad'
                                  ? 'bg-red-300'
                                  : ''
                              }`}
                            >
                              {cellValue}
                            </td>
                          );
                        }

                        // Default cell
                        return (
                          <td key={`${rowIndex}-${col}`} className="px-4 py-2 border">
                            {cellValue}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })
              : (
                <tr>
                  <td
                    colSpan={columns.length || 1}
                    className="px-4 py-4 text-center text-red-500"
                  >
                    No data to display
                  </td>
                </tr>
              )}
          </tbody>
        </table>
      </div>

      {/* ------------------- PAGINATION CONTROLS ------------------- */}
      {parsedData && totalRows > 0 && (
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            className="px-4 py-2 text-white bg-blue-500 rounded disabled:bg-gray-300 disabled:cursor-not-allowed"
            disabled={currentPage === 1}
          >
            Previous
          </button>

          <span className="font-semibold">
            Page {currentPage} of {totalPages}
          </span>

          <button
            onClick={() => handlePageChange(currentPage + 1)}
            className="px-4 py-2 text-white bg-blue-500 rounded disabled:bg-gray-300 disabled:cursor-not-allowed"
            disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default SpotWeldingTable;
