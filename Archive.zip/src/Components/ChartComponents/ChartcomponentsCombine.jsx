import React from 'react';
import { Line, Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement } from 'chart.js';

ChartJS.register(
    ArcElement,
    Tooltip,
    Legend,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement
);

const ChartComponentCombine = () => {
    // Dummy data for charts
    const lineData = {
        labels: ['Spot 1', 'Spot 2', 'Spot 3', 'Spot 4'],
        datasets: [
            {
                label: 'Energy Score',
                data: [73.4, 75.2, 72.8, 74.5],
                borderColor: 'rgba(75,192,192,1)',
                backgroundColor: 'rgba(75,192,192,0.2)',
                fill: true,
            },
        ],
    };

    const barData = {
        labels: ['Spot 1', 'Spot 2', 'Spot 3', 'Spot 4'],
        datasets: [
            {
                label: 'Resistance Score',
                data: [80.8, 79.5, 82.2, 81.0],
                backgroundColor: 'rgba(153,102,255,0.6)',
                borderColor: 'rgba(153,102,255,1)',
                borderWidth: 1,
            },
        ],
    };

    const pieData = {
        labels: ['Cluster 1', 'Cluster 2', 'Cluster 3'],
        datasets: [
            {
                label: 'Cluster Distribution',
                data: [40, 35, 25],
                backgroundColor: [
                    'rgba(255,99,132,0.6)',
                    'rgba(54,162,235,0.6)',
                    'rgba(255,206,86,0.6)',
                ],
                borderWidth: 1,
            },
        ],
    };

    const barOverallData = {
        labels: ['Spot 1', 'Spot 2', 'Spot 3', 'Spot 4'],
        datasets: [
            {
                label: 'Energy Scaled Value Overall',
                data: [0.557, 0.562, 0.550, 0.558],
                backgroundColor: 'rgba(255,159,64,0.6)',
                borderColor: 'rgba(255,159,64,1)',
                borderWidth: 1,
            },
        ],
    };

    const options = {
        responsive: true,
        maintainAspectRatio: true,
        aspectRatio: 2
    };

    return (
        <div className="grid w-full grid-cols-1 gap-6 md:grid-cols-2">
            <div className="p-4 bg-white rounded-md shadow-md">
                <h3 className="mb-3 text-lg font-semibold text-center">Energy Score Trend</h3>
                <div className="flex justify-center h-64">
                    <Line data={lineData} options={options} />
                </div>
            </div>
            <div className="p-4 bg-white rounded-md shadow-md">
                <h3 className="mb-3 text-lg font-semibold text-center">Resistance Score Comparison</h3>
                <div className="flex justify-center h-64">
                    <Bar data={barData} options={options} />
                </div>
            </div>
            <div className="p-4 bg-white rounded-md shadow-md">
                <h3 className="mb-3 text-lg font-semibold text-center">Cluster Distribution</h3>
                <div className="flex items-center justify-center h-64">
                    <div className="size-64">
                        <Pie data={pieData} options={{
                            responsive: true,
                            maintainAspectRatio: true,
                        }} />
                    </div>
                </div>
            </div>
            <div className="p-4 bg-white rounded-md shadow-md">
                <h3 className="mb-3 text-lg font-semibold text-center">Energy Scaled Value Overall</h3>
                <div className="flex justify-center h-64">
                    <Bar data={barOverallData} options={options} />
                </div>
            </div>
        </div>
    );
};

export default ChartComponentCombine;